# from __future__ import absolute_import
# from sciunit2.api import Sciunit
#
#
# class TestAPI:
#     def test_all(self):
#         _sciunit = Sciunit()
#         _sciunit.create('project1')
#         _sciunit.exec('pwd')
#         # _sciunit.commit()
#         _sciunit.repeat('e1')
